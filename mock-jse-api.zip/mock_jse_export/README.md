# JSE Trading API (MoMo Stokvel Invest)

Node.js/Express + SQLite backend simulating a **pooled/stokvel investment app**: members contribute cash into a shared pool, the pool trades JSE-listed instruments, and everyone can see combined portfolio performance.

## Real data vs. synthetic fallback

This API tries to use **real JSE prices from [Twelve Data](https://twelvedata.com)** and automatically falls back to a synthetic random-walk simulation for any instrument it can't get live data for. Nothing crashes or blocks if live data isn't available — it's a per-instrument, best-effort layer on top of a fully working synthetic engine.

**Important caveat, confirmed by testing:** Twelve Data's **free tier does not include JSE** — JSE access requires their paid "Grow" plan ($29/mo) or above. A free-tier key will get a `400`/plan-restriction error for any JSE symbol. This is normal, expected, and handled gracefully — check `GET /api/live-data-status` to see exactly which symbols are live vs. synthetic and why.

If you want genuinely live JSE prices for a demo, you'll need a paid Twelve Data key. Otherwise, the app runs perfectly well fully synthetic — the numbers just won't reflect the real market that day.

### Why not mystocks.africa?

That was the original ask, but on investigation their public marketing copy mixes plausible claims (an FSCA license, a sandbox) with red-flag language (real-money settlement via "blockchain stablecoins", "unified liquidity nodes") that doesn't match how a small hackathon-facing market-data API normally presents itself, and I couldn't independently verify the license or API contract. Given this handles pooled community money even in a demo, I didn't want to wire in an unverified third party — Twelve Data is a known, documented quantity instead.

## On-chain audit logging (optional)

Contributions can optionally be logged to the `StokvelAuditLog` smart contract
(see the separate `stokvel-contract` package) on Polygon Amoy, recording the
70/15/15 allocation split publicly and immutably. This is entirely optional —
without it configured, contributions work exactly as before and are simply
marked `onchainStatus: "not_configured"`.

To enable it:
1. Deploy `StokvelAuditLog` (see `stokvel-contract/README.md`) and note its address.
2. Set `POLYGON_AMOY_RPC_URL`, `BACKEND_WALLET_PRIVATE_KEY`, and `AUDIT_LOG_CONTRACT_ADDRESS` in `.env`.
3. New contributions will fire an async on-chain log after the off-chain record is saved — the API response is never blocked waiting on the chain. Each contribution row tracks `onchain_status` (`pending` → `confirmed`/`failed`) and `onchain_tx_hash` once confirmed.

**Important:** this is a logging layer, not a custody layer. The contract never holds or moves real money — MoMo payments and JSE trades happen entirely through this backend and its regulated partners. Only the backend's configured wallet can write new log entries; anyone can read the full history. See `stokvel-contract/README.md` for the full trust-model discussion.

## Setup

```bash
npm install
cp .env.example .env
# optionally add TWELVE_DATA_API_KEY to .env for live-data attempts
npm start        # or: npm run dev  (auto-restarts on file changes)
```

Server runs on `http://localhost:4000` by default.

## Data model

- **instruments** — 12 real JSE tickers (NPN, SOL, MTN, SBK, FSR, AGL, BHP, SHP, VOD, CPI, BID, PRX). Each tracks `price_source` (`twelve_data` or `synthetic`) so the frontend can be honest about which prices are real.
- **pools** — one collective "stokvel" account (`default-pool` seeded on first run). Create more via `POST /api/pool`.
- **contributions** — member cash-ins to a pool.
- **holdings** — pool's current share holdings, average cost basis.
- **orders** — buy/sell order history, including rejected ones with a reason.
- **price_history** — tick-by-tick price + volume, used for charting (mix of live and synthetic points, tagged implicitly by source at time of insert).

## How pricing works

Two independent schedules, both configurable via `.env`:

1. **`TICK_CRON`** (default every 5s) — the synthetic random-walk step. Only touches instruments currently on the `synthetic` source, so it never fights with live data.
2. **`LIVE_SYNC_CRON`** (default every 2 min) — attempts a real Twelve Data quote for every instrument. Kept slow deliberately: Twelve Data's free tier allows 8 requests/minute and 800/day; even on a paid plan, hammering it isn't necessary for a demo. Runs once immediately on startup, then on schedule.

`GET /api/live-data-status` shows exactly which symbols are live and which failed, with the specific reason (no API key, plan restriction, bad symbol match, rate limit, network error) — useful for debugging your Twelve Data plan/key without guessing.

## API Reference

### Instruments / Quotes
- `GET /api/instruments` — all instruments with live quote (price, change, change%, day range, `priceSource`)
- `GET /api/instruments/:symbol` — single instrument quote

### Historical Data
- `GET /api/history/:symbol?limit=100` — price/volume time series (oldest → newest)

### Orders (trading)
- `POST /api/orders` — place an order
  ```json
  {
    "poolId": "default-pool",
    "symbol": "NPN",
    "side": "BUY",
    "quantity": 10,
    "orderType": "MARKET",
    "limitPrice": 3400
  }
  ```
  MARKET orders fill immediately at current price, or `REJECTED` with a reason if funds/holdings are insufficient. LIMIT orders fill immediately if already satisfied, else sit `PENDING` (no background re-check loop yet — see Next Steps).
- `GET /api/orders?poolId=default-pool` — order history
- `GET /api/orders/:id` — single order

### Portfolio
- `GET /api/portfolio/:poolId` — cash balance, holdings with market value + unrealized P&L, total value, total contributed

### Pool / Contributions
- `POST /api/pool` — create a pool: `{ "name": "..." }`
- `GET /api/pool/:poolId` — pool info
- `POST /api/pool/:poolId/contributions` — `{ "memberId": "...", "memberName": "...", "amount": 500 }`
- `GET /api/pool/:poolId/contributions` — contribution history

### Diagnostics
- `GET /health`
- `GET /api/live-data-status` — per-symbol live/synthetic status and failure reasons

## Next steps / known gaps

- **Fractional shares**: quantities are whole-share integers today. Your pitch mentions investing "from R10" — worth switching `quantity` to support decimals if fractional investing is core to the demo.
- **Round-up contributions**: not modeled yet — would need an endpoint that takes a transaction amount and computes the round-up delta into the pool.
- **Member voting/governance**: not modeled — separate feature from market data.
- **LIMIT orders**: only checked at placement time, not re-evaluated on later ticks/syncs.
- **No auth**: `memberId` is a free-text string; wire up to your real user system.
- **No fees/slippage**: real brokers charge brokerage, STT, STRATE, etc.
- **SQLite**: fine for a demo; move to a shared DB (e.g. Cloud SQL) if you deploy multiple instances on GCP.

## A note on the `dotenv` dependency

This project pins `dotenv@16.6.1` deliberately. Newer `dotenv` v17.x releases print a startup console line advertising a third-party URL (`vestauth.com`) baked into the package itself — not obviously malicious, but unwanted vendor messaging in a fintech-adjacent server. Worth checking again before ever bumping this dependency.
