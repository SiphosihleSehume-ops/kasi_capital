const express = require('express');
const { db } = require('../db');
const router = express.Router();

// GET /api/history/:symbol?limit=100
router.get('/:symbol', (req, res) => {
  const symbol = req.params.symbol.toUpperCase();
  const limit = Math.min(parseInt(req.query.limit) || 100, 5000);

  const instrument = db.prepare('SELECT symbol FROM instruments WHERE symbol = ?').get(symbol);
  if (!instrument) return res.status(404).json({ error: `Unknown symbol: ${symbol}` });

  const rows = db.prepare(`
    SELECT price, volume, ts FROM price_history
    WHERE symbol = ?
    ORDER BY ts DESC
    LIMIT ?
  `).all(symbol, limit);

  res.json({ symbol, count: rows.length, history: rows.reverse() });
});

module.exports = router;
