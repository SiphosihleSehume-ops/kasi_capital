const express = require('express');
const { db } = require('../db');
const router = express.Router();

// GET /api/instruments - list all instruments with live quote data
router.get('/', (req, res) => {
  const rows = db.prepare('SELECT * FROM instruments ORDER BY symbol').all();
  const quotes = rows.map(formatQuote);
  res.json({ count: quotes.length, instruments: quotes });
});

// GET /api/instruments/:symbol - single instrument quote
router.get('/:symbol', (req, res) => {
  const symbol = req.params.symbol.toUpperCase();
  const row = db.prepare('SELECT * FROM instruments WHERE symbol = ?').get(symbol);
  if (!row) return res.status(404).json({ error: `Unknown symbol: ${symbol}` });
  res.json(formatQuote(row));
});

function formatQuote(row) {
  const change = row.last_price - row.prev_close;
  const changePct = row.prev_close ? (change / row.prev_close) * 100 : 0;
  return {
    symbol: row.symbol,
    name: row.name,
    sector: row.sector,
    price: row.last_price,
    prevClose: row.prev_close,
    dayOpen: row.day_open,
    dayHigh: row.day_high,
    dayLow: row.day_low,
    change: Math.round(change * 100) / 100,
    changePct: Math.round(changePct * 100) / 100,
    priceSource: row.price_source, // 'twelve_data' or 'synthetic' — be honest with the frontend
    updatedAt: row.updated_at,
  };
}

module.exports = router;
