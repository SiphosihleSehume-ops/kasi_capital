const express = require('express');
const { db, randomUUID } = require('../db');
const router = express.Router();

// POST /api/orders
// body: { poolId, symbol, side: 'BUY'|'SELL', quantity, orderType: 'MARKET'|'LIMIT', limitPrice? }
router.post('/', (req, res) => {
  const { poolId = 'default-pool', symbol, side, quantity, orderType = 'MARKET', limitPrice } = req.body;

  if (!symbol || !side || !quantity) {
    return res.status(400).json({ error: 'symbol, side, and quantity are required' });
  }
  if (!['BUY', 'SELL'].includes(side)) {
    return res.status(400).json({ error: "side must be 'BUY' or 'SELL'" });
  }
  if (!Number.isInteger(quantity) || quantity <= 0) {
    return res.status(400).json({ error: 'quantity must be a positive integer' });
  }
  if (orderType === 'LIMIT' && !limitPrice) {
    return res.status(400).json({ error: 'limitPrice is required for LIMIT orders' });
  }

  const upperSymbol = symbol.toUpperCase();
  const instrument = db.prepare('SELECT * FROM instruments WHERE symbol = ?').get(upperSymbol);
  if (!instrument) return res.status(404).json({ error: `Unknown symbol: ${upperSymbol}` });

  const pool = db.prepare('SELECT * FROM pools WHERE id = ?').get(poolId);
  if (!pool) return res.status(404).json({ error: `Unknown pool: ${poolId}` });

  const orderId = randomUUID();
  const currentPrice = instrument.last_price;

  // For MARKET orders, fill immediately at current price.
  // For LIMIT orders, only fill if the current price satisfies the limit; otherwise stays PENDING.
  let fillPrice = null;
  let status = 'PENDING';
  let rejectReason = null;

  const shouldFillNow =
    orderType === 'MARKET' ||
    (orderType === 'LIMIT' && side === 'BUY' && currentPrice <= limitPrice) ||
    (orderType === 'LIMIT' && side === 'SELL' && currentPrice >= limitPrice);

  const executeTx = db.transaction(() => {
    if (side === 'BUY') {
      const cost = (orderType === 'MARKET' ? currentPrice : limitPrice) * quantity;
      if (shouldFillNow && cost > pool.cash_balance) {
        status = 'REJECTED';
        rejectReason = `Insufficient pool funds: need R${cost.toFixed(2)}, have R${pool.cash_balance.toFixed(2)}`;
      } else if (shouldFillNow) {
        fillPrice = orderType === 'MARKET' ? currentPrice : limitPrice;
        status = 'FILLED';
        db.prepare('UPDATE pools SET cash_balance = cash_balance - ? WHERE id = ?').run(cost, poolId);

        const holding = db.prepare('SELECT * FROM holdings WHERE pool_id = ? AND symbol = ?').get(poolId, upperSymbol);
        if (holding) {
          const newQty = holding.quantity + quantity;
          const newAvg = ((holding.avg_price * holding.quantity) + (fillPrice * quantity)) / newQty;
          db.prepare('UPDATE holdings SET quantity = ?, avg_price = ? WHERE pool_id = ? AND symbol = ?')
            .run(newQty, newAvg, poolId, upperSymbol);
        } else {
          db.prepare('INSERT INTO holdings (pool_id, symbol, quantity, avg_price) VALUES (?, ?, ?, ?)')
            .run(poolId, upperSymbol, quantity, fillPrice);
        }
      }
    } else {
      // SELL
      const holding = db.prepare('SELECT * FROM holdings WHERE pool_id = ? AND symbol = ?').get(poolId, upperSymbol);
      const heldQty = holding ? holding.quantity : 0;

      if (shouldFillNow && heldQty < quantity) {
        status = 'REJECTED';
        rejectReason = `Insufficient holdings: trying to sell ${quantity}, pool holds ${heldQty}`;
      } else if (shouldFillNow) {
        fillPrice = orderType === 'MARKET' ? currentPrice : limitPrice;
        status = 'FILLED';
        const proceeds = fillPrice * quantity;
        db.prepare('UPDATE pools SET cash_balance = cash_balance + ? WHERE id = ?').run(proceeds, poolId);

        const newQty = heldQty - quantity;
        if (newQty === 0) {
          db.prepare('DELETE FROM holdings WHERE pool_id = ? AND symbol = ?').run(poolId, upperSymbol);
        } else {
          db.prepare('UPDATE holdings SET quantity = ? WHERE pool_id = ? AND symbol = ?')
            .run(newQty, poolId, upperSymbol);
        }
      }
    }

    db.prepare(`
      INSERT INTO orders (id, pool_id, symbol, side, order_type, quantity, limit_price, status, fill_price, reject_reason, filled_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      orderId, poolId, upperSymbol, side, orderType, quantity,
      limitPrice || null, status, fillPrice, rejectReason,
      status === 'FILLED' ? new Date().toISOString() : null
    );
  });

  executeTx();

  const savedOrder = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);
  const httpStatus = status === 'REJECTED' ? 422 : 201;
  res.status(httpStatus).json(savedOrder);
});

// GET /api/orders?poolId=default-pool
router.get('/', (req, res) => {
  const poolId = req.query.poolId || 'default-pool';
  const orders = db.prepare('SELECT * FROM orders WHERE pool_id = ? ORDER BY created_at DESC').all(poolId);
  res.json({ count: orders.length, orders });
});

// GET /api/orders/:id
router.get('/:id', (req, res) => {
  const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found' });
  res.json(order);
});

module.exports = router;
