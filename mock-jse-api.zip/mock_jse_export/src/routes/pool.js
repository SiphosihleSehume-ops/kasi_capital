const express = require('express');
const { db, randomUUID } = require('../db');
const auditLogChain = require('../services/auditLogChain');
const router = express.Router();

// POST /api/pool/:poolId/contributions
// body: { memberId, memberName, amount }
router.post('/:poolId/contributions', (req, res) => {
  const { poolId } = req.params;
  const { memberId, memberName, amount } = req.body;

  if (!memberId || !amount || amount <= 0) {
    return res.status(400).json({ error: 'memberId and a positive amount are required' });
  }

  const pool = db.prepare('SELECT * FROM pools WHERE id = ?').get(poolId);
  if (!pool) return res.status(404).json({ error: `Unknown pool: ${poolId}` });

  const contributionId = randomUUID();
  const initialOnchainStatus = auditLogChain.isConfigured() ? 'pending' : 'not_configured';

  const tx = db.transaction(() => {
    db.prepare(`
      INSERT INTO contributions (id, pool_id, member_id, member_name, amount, onchain_status)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(contributionId, poolId, memberId, memberName || null, amount, initialOnchainStatus);

    db.prepare('UPDATE pools SET cash_balance = cash_balance + ? WHERE id = ?').run(amount, poolId);
  });
  tx();

  const updatedPool = db.prepare('SELECT * FROM pools WHERE id = ?').get(poolId);

  // Respond immediately — the off-chain contribution is the source of truth
  // and must never wait on a blockchain round-trip. The on-chain log is
  // best-effort and updates the row asynchronously once it resolves.
  res.status(201).json({
    contributionId,
    poolId,
    memberId,
    amount,
    newCashBalance: Math.round(updatedPool.cash_balance * 100) / 100,
    onchainStatus: initialOnchainStatus,
  });

  if (initialOnchainStatus === 'pending') {
    auditLogChain.logContribution(memberId, amount).then((result) => {
      if (result.ok) {
        db.prepare('UPDATE contributions SET onchain_status = ?, onchain_tx_hash = ? WHERE id = ?')
          .run('confirmed', result.txHash, contributionId);
      } else {
        db.prepare('UPDATE contributions SET onchain_status = ? WHERE id = ?')
          .run('failed', contributionId);
        console.error(`On-chain log failed for contribution ${contributionId}: ${result.reason}`);
      }
    });
  }
});

// GET /api/pool/:poolId/contributions
router.get('/:poolId/contributions', (req, res) => {
  const { poolId } = req.params;
  const rows = db.prepare('SELECT * FROM contributions WHERE pool_id = ? ORDER BY ts DESC').all(poolId);
  res.json({ count: rows.length, contributions: rows });
});

// GET /api/pool/:poolId - basic pool info
router.get('/:poolId', (req, res) => {
  const pool = db.prepare('SELECT * FROM pools WHERE id = ?').get(req.params.poolId);
  if (!pool) return res.status(404).json({ error: 'Pool not found' });
  res.json(pool);
});

// POST /api/pool - create a new pool
router.post('/', (req, res) => {
  const { name } = req.body;
  if (!name) return res.status(400).json({ error: 'name is required' });
  const id = randomUUID();
  db.prepare('INSERT INTO pools (id, name, cash_balance) VALUES (?, ?, 0)').run(id, name);
  res.status(201).json({ id, name, cashBalance: 0 });
});

module.exports = router;
