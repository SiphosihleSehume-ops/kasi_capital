const express = require('express');
const { db } = require('../db');
const router = express.Router();

// GET /api/portfolio/:poolId
router.get('/:poolId', (req, res) => {
  const { poolId } = req.params;
  const pool = db.prepare('SELECT * FROM pools WHERE id = ?').get(poolId);
  if (!pool) return res.status(404).json({ error: `Unknown pool: ${poolId}` });

  const holdings = db.prepare(`
    SELECT h.symbol, h.quantity, h.avg_price, i.name, i.last_price
    FROM holdings h JOIN instruments i ON h.symbol = i.symbol
    WHERE h.pool_id = ?
  `).all(poolId);

  let holdingsValue = 0;
  const enriched = holdings.map(h => {
    const marketValue = h.quantity * h.last_price;
    const costBasis = h.quantity * h.avg_price;
    const unrealizedPnl = marketValue - costBasis;
    holdingsValue += marketValue;
    return {
      symbol: h.symbol,
      name: h.name,
      quantity: h.quantity,
      avgPrice: Math.round(h.avg_price * 100) / 100,
      currentPrice: h.last_price,
      marketValue: Math.round(marketValue * 100) / 100,
      unrealizedPnl: Math.round(unrealizedPnl * 100) / 100,
      unrealizedPnlPct: costBasis ? Math.round((unrealizedPnl / costBasis) * 10000) / 100 : 0,
    };
  });

  const totalContributed = db.prepare(
    'SELECT COALESCE(SUM(amount),0) AS total FROM contributions WHERE pool_id = ?'
  ).get(poolId).total;

  res.json({
    poolId,
    poolName: pool.name,
    cashBalance: Math.round(pool.cash_balance * 100) / 100,
    holdingsValue: Math.round(holdingsValue * 100) / 100,
    totalValue: Math.round((pool.cash_balance + holdingsValue) * 100) / 100,
    totalContributed: Math.round(totalContributed * 100) / 100,
    holdings: enriched,
  });
});

module.exports = router;
