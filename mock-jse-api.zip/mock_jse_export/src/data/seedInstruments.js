// Real JSE-listed tickers. `searchName` is used to resolve the correct
// Twelve Data symbol via /symbol_search. Price/volatility/drift are the
// seed and fallback values used by the synthetic random-walk engine
// whenever live data isn't available for that instrument.
module.exports = [
  { symbol: 'NPN', name: 'Naspers Ltd',            searchName: 'Naspers',        sector: 'Technology',      price: 3450.00, volatility: 0.018, drift: 0.0002 },
  { symbol: 'PRX', name: 'Prosus NV',               searchName: 'Prosus',         sector: 'Technology',      price: 1180.50, volatility: 0.017, drift: 0.0001 },
  { symbol: 'SOL', name: 'Sasol Ltd',               searchName: 'Sasol',          sector: 'Energy',          price: 142.30,  volatility: 0.028, drift: -0.0002 },
  { symbol: 'MTN', name: 'MTN Group Ltd',           searchName: 'MTN Group',      sector: 'Telecoms',        price: 98.75,   volatility: 0.022, drift: 0.0001 },
  { symbol: 'SBK', name: 'Standard Bank Group',     searchName: 'Standard Bank',  sector: 'Financials',      price: 215.40,  volatility: 0.015, drift: 0.0003 },
  { symbol: 'FSR', name: 'FirstRand Ltd',           searchName: 'FirstRand',      sector: 'Financials',      price: 68.90,   volatility: 0.014, drift: 0.0002 },
  { symbol: 'AGL', name: 'Anglo American plc',      searchName: 'Anglo American', sector: 'Mining',          price: 520.60,  volatility: 0.025, drift: 0.0000 },
  { symbol: 'BHP', name: 'BHP Group Ltd (JSE)',     searchName: 'BHP Group',      sector: 'Mining',          price: 480.20,  volatility: 0.020, drift: 0.0001 },
  { symbol: 'SHP', name: 'Shoprite Holdings',       searchName: 'Shoprite',       sector: 'Retail',          price: 275.10,  volatility: 0.013, drift: 0.0002 },
  { symbol: 'VOD', name: 'Vodacom Group Ltd',       searchName: 'Vodacom',        sector: 'Telecoms',        price: 132.85,  volatility: 0.012, drift: 0.0001 },
  { symbol: 'CPI', name: 'Capitec Bank Holdings',   searchName: 'Capitec',        sector: 'Financials',      price: 2210.00, volatility: 0.019, drift: 0.0004 },
  { symbol: 'BID', name: 'Bid Corporation Ltd',     searchName: 'Bid Corporation',sector: 'Consumer',        price: 385.75,  volatility: 0.016, drift: 0.0002 },
];
