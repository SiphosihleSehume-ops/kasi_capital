// Client for the Twelve Data API (https://twelvedata.com/docs).
//
// JSE access on Twelve Data requires the paid "Grow" plan or above —
// a free-tier key will get errors for JSE symbols. Rather than assume
// one way or the other, every function here fails soft: on any error
// (bad symbol, plan restriction, rate limit, network issue) it returns
// { ok: false, reason, detail } instead of throwing, so callers can
// fall back to the synthetic price engine per-instrument.
//
// Symbol format on Twelve Data varies by exchange/provider, so instead
// of hardcoding a guess (e.g. "NPN:JSE"), we resolve it once via
// /symbol_search and cache the result.

const axios = require('axios');

const BASE_URL = 'https://api.twelvedata.com';
const REQUEST_TIMEOUT_MS = 8000;

// symbol -> resolved Twelve Data symbol string (cached after first successful lookup)
const resolvedSymbolCache = new Map();

function getApiKey() {
  // read lazily so this works regardless of require order vs dotenv.config()
  return process.env.TWELVE_DATA_API_KEY || null;
}

function isLogicalError(json) {
  // Twelve Data returns HTTP 200 even for logical errors; the body carries the error.
  return !json || json.status === 'error' || typeof json.code === 'number';
}

/**
 * Look up how Twelve Data identifies a given company on the JSE, using
 * their own symbol search rather than guessing a format.
 * @param {string} name - company name or ticker hint, e.g. "Naspers" or "NPN"
 * @returns {Promise<{ok: true, symbol: string} | {ok: false, reason: string, detail?: any}>}
 */
async function resolveJseSymbol(name) {
  if (resolvedSymbolCache.has(name)) {
    return { ok: true, symbol: resolvedSymbolCache.get(name) };
  }

  const apiKey = getApiKey();
  if (!apiKey) return { ok: false, reason: 'NO_API_KEY' };

  try {
    const response = await axios.get(`${BASE_URL}/symbol_search`, {
      params: { symbol: name, outputsize: 10 },
      timeout: REQUEST_TIMEOUT_MS,
    });
    const json = response.data;
    if (isLogicalError(json)) {
      return { ok: false, reason: 'API_ERROR', detail: json.message || json };
    }

    const matches = json.data || [];
    const jseMatch = matches.find(m => (m.exchange || '').toUpperCase() === 'JSE');
    if (!jseMatch) {
      return { ok: false, reason: 'NO_JSE_MATCH', detail: matches };
    }

    resolvedSymbolCache.set(name, jseMatch.symbol);
    return { ok: true, symbol: jseMatch.symbol };
  } catch (err) {
    const detail = err.response ? err.response.data : err.message;
    return { ok: false, reason: 'REQUEST_FAILED', detail };
  }
}

/**
 * Fetch a live quote for a resolved Twelve Data symbol.
 * @param {string} twelveDataSymbol - the exact symbol Twelve Data expects
 * @returns {Promise<{ok: true, data: object} | {ok: false, reason: string, detail?: any}>}
 */
async function fetchQuote(twelveDataSymbol) {
  const apiKey = getApiKey();
  if (!apiKey) return { ok: false, reason: 'NO_API_KEY' };

  try {
    const response = await axios.get(`${BASE_URL}/quote`, {
      params: { symbol: twelveDataSymbol, apikey: apiKey },
      timeout: REQUEST_TIMEOUT_MS,
    });
    const json = response.data;

    if (isLogicalError(json)) {
      return { ok: false, reason: 'API_ERROR', detail: json.message || json };
    }

    const price = parseFloat(json.close);
    if (Number.isNaN(price)) {
      return { ok: false, reason: 'NO_PRICE_IN_RESPONSE', detail: json };
    }

    return {
      ok: true,
      data: {
        price,
        prevClose: parseFloat(json.previous_close) || price,
        dayOpen: parseFloat(json.open) || price,
        dayHigh: parseFloat(json.high) || price,
        dayLow: parseFloat(json.low) || price,
        volume: parseInt(json.volume, 10) || 0,
        source: 'twelve_data',
      },
    };
  } catch (err) {
    const detail = err.response ? err.response.data : err.message;
    return { ok: false, reason: 'REQUEST_FAILED', detail };
  }
}

/**
 * Fetch historical daily bars for a resolved Twelve Data symbol.
 * @param {string} twelveDataSymbol
 * @param {number} outputsize - number of bars, max 5000
 */
async function fetchHistory(twelveDataSymbol, outputsize = 100) {
  const apiKey = getApiKey();
  if (!apiKey) return { ok: false, reason: 'NO_API_KEY' };

  try {
    const response = await axios.get(`${BASE_URL}/time_series`, {
      params: { symbol: twelveDataSymbol, interval: '1day', outputsize, apikey: apiKey },
      timeout: REQUEST_TIMEOUT_MS,
    });
    const json = response.data;

    if (isLogicalError(json)) {
      return { ok: false, reason: 'API_ERROR', detail: json.message || json };
    }

    const values = json.values || [];
    return {
      ok: true,
      data: values.map(v => ({
        ts: v.datetime,
        price: parseFloat(v.close),
        volume: parseInt(v.volume, 10) || 0,
      })).reverse(), // Twelve Data returns newest-first; we want oldest-first
    };
  } catch (err) {
    const detail = err.response ? err.response.data : err.message;
    return { ok: false, reason: 'REQUEST_FAILED', detail };
  }
}

module.exports = { resolveJseSymbol, fetchQuote, fetchHistory };
