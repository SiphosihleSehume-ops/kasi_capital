// Calls the StokvelAuditLog contract on Polygon Amoy to log contributions
// and payouts on-chain. Fails soft on every path: if the contract isn't
// configured, the RPC is unreachable, or the tx fails, we log a warning and
// let the off-chain flow (which is the source of truth for actual money
// movement) continue unaffected. On-chain logging is a transparency layer,
// not a dependency the app relies on to function.

const { ethers } = require('ethers');

const CONTRACT_ABI = [
  'function logContribution(string memberId, uint256 amountCents) external returns (uint256)',
  'function logPayout(string memberId, uint256 amountCents, string quarterLabel) external returns (uint256)',
  'event ContributionLogged(uint256 indexed index, string indexed memberId, string memberIdPlain, uint256 amountCents, uint256 investAmountCents, uint256 mtnFeeAmountCents, uint256 quarterlyPayoutAmountCents, uint256 timestamp)',
];

let cachedContract = null;
let cachedWallet = null;

function isConfigured() {
  return Boolean(
    process.env.POLYGON_AMOY_RPC_URL &&
    process.env.BACKEND_WALLET_PRIVATE_KEY &&
    process.env.AUDIT_LOG_CONTRACT_ADDRESS
  );
}

function getContract() {
  if (cachedContract) return cachedContract;
  if (!isConfigured()) return null;

  try {
    const provider = new ethers.JsonRpcProvider(process.env.POLYGON_AMOY_RPC_URL);
    cachedWallet = new ethers.Wallet(process.env.BACKEND_WALLET_PRIVATE_KEY, provider);
    cachedContract = new ethers.Contract(
      process.env.AUDIT_LOG_CONTRACT_ADDRESS,
      CONTRACT_ABI,
      cachedWallet
    );
    return cachedContract;
  } catch (err) {
    console.error('Failed to initialize audit-log contract client:', err.message);
    return null;
  }
}

/**
 * Logs a contribution on-chain. Fire-and-forget from the caller's
 * perspective — returns a status object but never throws.
 * @param {string} memberId
 * @param {number} amountRands - contribution amount in Rand (will be converted to cents)
 */
async function logContribution(memberId, amountRands) {
  if (!isConfigured()) {
    return { ok: false, reason: 'NOT_CONFIGURED' };
  }
  const contract = getContract();
  if (!contract) {
    return { ok: false, reason: 'CLIENT_INIT_FAILED' };
  }

  try {
    const amountCents = BigInt(Math.round(amountRands * 100));
    const tx = await contract.logContribution(memberId, amountCents);
    const receipt = await tx.wait();
    return { ok: true, txHash: receipt.hash, blockNumber: receipt.blockNumber };
  } catch (err) {
    console.error(`On-chain contribution log failed for ${memberId}:`, err.message);
    return { ok: false, reason: 'TX_FAILED', detail: err.message };
  }
}

/**
 * Logs a quarterly payout on-chain. Same fail-soft contract as logContribution.
 */
async function logPayout(memberId, amountRands, quarterLabel) {
  if (!isConfigured()) {
    return { ok: false, reason: 'NOT_CONFIGURED' };
  }
  const contract = getContract();
  if (!contract) {
    return { ok: false, reason: 'CLIENT_INIT_FAILED' };
  }

  try {
    const amountCents = BigInt(Math.round(amountRands * 100));
    const tx = await contract.logPayout(memberId, amountCents, quarterLabel);
    const receipt = await tx.wait();
    return { ok: true, txHash: receipt.hash, blockNumber: receipt.blockNumber };
  } catch (err) {
    console.error(`On-chain payout log failed for ${memberId}:`, err.message);
    return { ok: false, reason: 'TX_FAILED', detail: err.message };
  }
}

module.exports = { logContribution, logPayout, isConfigured };
