const { db } = require('../db');
const twelveData = require('./twelveDataClient');
const seedInstruments = require('../data/seedInstruments');

// Box-Muller transform for normally-distributed random numbers
function gaussianRandom(mean = 0, stddev = 1) {
  const u1 = Math.random();
  const u2 = Math.random();
  const z0 = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
  return mean + z0 * stddev;
}

const selectAll = db.prepare('SELECT * FROM instruments');
const updateInstrumentLive = db.prepare(`
  UPDATE instruments
  SET last_price = @last_price,
      prev_close = @prev_close,
      day_open = @day_open,
      day_high = @day_high,
      day_low = @day_low,
      price_source = 'twelve_data',
      twelve_data_symbol = @twelve_data_symbol,
      updated_at = datetime('now')
  WHERE symbol = @symbol
`);
const updateInstrumentSynthetic = db.prepare(`
  UPDATE instruments
  SET last_price = @last_price,
      day_high = @day_high,
      day_low = @day_low,
      updated_at = datetime('now')
  WHERE symbol = @symbol
`);
const insertHistory = db.prepare(`
  INSERT INTO price_history (symbol, price, volume) VALUES (@symbol, @price, @volume)
`);

const searchNameBySymbol = new Map(seedInstruments.map(i => [i.symbol, i.searchName]));

// Per-symbol record of the last live-data attempt, for the /api/live-data-status
// endpoint — lets you see exactly why a symbol is or isn't getting real prices.
const liveDataStatus = new Map();

function getLiveDataStatus() {
  return Object.fromEntries(liveDataStatus);
}

// --- Synthetic random-walk tick: runs frequently, covers every instrument
// that isn't currently getting live data (or as a fallback if live data
// has never succeeded for it yet). ---
function tick() {
  const instruments = selectAll.all();
  const tx = db.transaction((rows) => {
    for (const inst of rows) {
      // Don't let the fast synthetic tick fight with genuinely live prices —
      // only step instruments that are on synthetic (or new/unknown) source.
      if (inst.price_source === 'twelve_data') continue;

      const pctChange = gaussianRandom(inst.drift, inst.volatility);
      let newPrice = inst.last_price * (1 + pctChange);
      newPrice = Math.max(newPrice, 0.50); // floor so prices never go to zero/negative
      newPrice = Math.round(newPrice * 100) / 100;

      const day_high = Math.max(inst.day_high, newPrice);
      const day_low = Math.min(inst.day_low, newPrice);
      const volume = Math.floor(Math.random() * 5000) + 100;

      updateInstrumentSynthetic.run({ symbol: inst.symbol, last_price: newPrice, day_high, day_low });
      insertHistory.run({ symbol: inst.symbol, price: newPrice, volume });
    }
  });
  tx(instruments);
}

// --- Live data sync: runs infrequently (see index.js schedule) to respect
// Twelve Data's rate limits. Tries each instrument independently; a failure
// on one symbol never blocks the others, and just leaves that symbol on
// the synthetic tick above. ---
async function syncLiveData() {
  const instruments = selectAll.all();

  for (const inst of instruments) {
    const searchName = searchNameBySymbol.get(inst.symbol) || inst.name;

    try {
      let tdSymbol = inst.twelve_data_symbol;
      if (!tdSymbol) {
        const resolved = await twelveData.resolveJseSymbol(searchName);
        if (!resolved.ok) {
          liveDataStatus.set(inst.symbol, { live: false, reason: resolved.reason, detail: resolved.detail });
          continue;
        }
        tdSymbol = resolved.symbol;
      }

      const quote = await twelveData.fetchQuote(tdSymbol);
      if (!quote.ok) {
        liveDataStatus.set(inst.symbol, { live: false, reason: quote.reason, detail: quote.detail });
        continue;
      }

      updateInstrumentLive.run({
        symbol: inst.symbol,
        last_price: quote.data.price,
        prev_close: quote.data.prevClose,
        day_open: quote.data.dayOpen,
        day_high: quote.data.dayHigh,
        day_low: quote.data.dayLow,
        twelve_data_symbol: tdSymbol,
      });
      insertHistory.run({ symbol: inst.symbol, price: quote.data.price, volume: quote.data.volume });
      liveDataStatus.set(inst.symbol, { live: true, twelveDataSymbol: tdSymbol });
    } catch (err) {
      // Defensive: never let one bad symbol crash the whole sync loop.
      liveDataStatus.set(inst.symbol, { live: false, reason: 'UNEXPECTED_ERROR', detail: String(err) });
    }
  }
}

// Reset day_open/prev_close/day_high/day_low at the start of a new "trading day".
// Only meaningful for synthetic instruments — live instruments get these
// fields from Twelve Data directly on each successful sync.
function rolloverDay() {
  const instruments = selectAll.all();
  const rollTx = db.transaction((rows) => {
    for (const inst of rows) {
      if (inst.price_source === 'twelve_data') continue;
      db.prepare(`
        UPDATE instruments
        SET prev_close = last_price, day_open = last_price, day_high = last_price, day_low = last_price
        WHERE symbol = @symbol
      `).run({ symbol: inst.symbol });
    }
  });
  rollTx(instruments);
}

module.exports = { tick, syncLiveData, rolloverDay, getLiveDataStatus, gaussianRandom };
