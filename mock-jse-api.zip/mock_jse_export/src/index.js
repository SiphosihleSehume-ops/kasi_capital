require('dotenv').config();
const express = require('express');
const cors = require('cors');
const cron = require('node-cron');

const { init } = require('./db');
init(); // must run before any module prepares SQL statements against these tables

const priceEngine = require('./services/priceEngine');

const instrumentsRouter = require('./routes/instruments');
const historyRouter = require('./routes/history');
const ordersRouter = require('./routes/orders');
const portfolioRouter = require('./routes/portfolio');
const poolRouter = require('./routes/pool');

const app = express();
const PORT = process.env.PORT || 4000;
const TICK_CRON = process.env.TICK_CRON || '*/5 * * * * *'; // every 5 seconds by default
// Live-data sync runs far less often than the synthetic tick to respect
// Twelve Data's free-tier rate limit (8 req/min, 800/day). Every 2 minutes
// with 12 instruments = 6 req/min, well under the cap.
const LIVE_SYNC_CRON = process.env.LIVE_SYNC_CRON || '*/2 * * * *';

app.use(cors());
app.use(express.json());

app.get('/health', (req, res) => res.json({ status: 'ok', service: 'mock-jse-api' }));

// Reports which symbols are getting real Twelve Data prices vs. the synthetic
// fallback, and why — use this to confirm your API plan/symbol format.
app.get('/api/live-data-status', (req, res) => {
  res.json({
    twelveDataConfigured: Boolean(process.env.TWELVE_DATA_API_KEY),
    perSymbol: priceEngine.getLiveDataStatus(),
  });
});

app.use('/api/instruments', instrumentsRouter);
app.use('/api/history', historyRouter);
app.use('/api/orders', ordersRouter);
app.use('/api/portfolio', portfolioRouter);
app.use('/api/pool', poolRouter);

app.use((req, res) => res.status(404).json({ error: 'Not found' }));
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Internal server error' });
});

// Synthetic random-walk tick — always runs, covers any symbol Twelve Data
// couldn't provide (wrong plan, bad symbol format, rate-limited, offline).
cron.schedule(TICK_CRON, () => {
  priceEngine.tick();
});

// Attempts to overwrite prices with real Twelve Data quotes on a slower
// schedule. Symbols that succeed get real data; symbols that fail keep
// moving via the synthetic tick above. Runs once immediately on startup too.
if (process.env.TWELVE_DATA_API_KEY) {
  priceEngine.syncLiveData().catch((err) => console.error('Initial live sync failed:', err));
  cron.schedule(LIVE_SYNC_CRON, () => {
    priceEngine.syncLiveData().catch((err) => console.error('Live sync failed:', err));
  });
} else {
  console.log('TWELVE_DATA_API_KEY not set — running on synthetic prices only.');
}

app.listen(PORT, () => {
  console.log(`Mock JSE API running on port ${PORT}`);
  console.log(`Synthetic tick schedule: ${TICK_CRON}`);
  console.log(`Live-data sync schedule: ${LIVE_SYNC_CRON}`);
});
