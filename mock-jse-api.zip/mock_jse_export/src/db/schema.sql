-- Mock JSE API schema

CREATE TABLE IF NOT EXISTS instruments (
    symbol TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    sector TEXT NOT NULL,
    last_price REAL NOT NULL,
    prev_close REAL NOT NULL,
    day_open REAL NOT NULL,
    day_high REAL NOT NULL,
    day_low REAL NOT NULL,
    volatility REAL NOT NULL DEFAULT 0.02,  -- stddev of pct move per tick (fallback engine)
    drift REAL NOT NULL DEFAULT 0.0,        -- slight upward/downward bias per tick (fallback engine)
    price_source TEXT NOT NULL DEFAULT 'synthetic' CHECK(price_source IN ('twelve_data','synthetic')),
    twelve_data_symbol TEXT,                -- resolved Twelve Data symbol, once known
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS price_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol TEXT NOT NULL REFERENCES instruments(symbol),
    price REAL NOT NULL,
    volume INTEGER NOT NULL DEFAULT 0,
    ts TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_price_history_symbol_ts ON price_history(symbol, ts);

-- The pool: a single collective account (or multiple pools if you want groups later)
CREATE TABLE IF NOT EXISTS pools (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    cash_balance REAL NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS contributions (
    id TEXT PRIMARY KEY,
    pool_id TEXT NOT NULL REFERENCES pools(id),
    member_id TEXT NOT NULL,
    member_name TEXT,
    amount REAL NOT NULL,
    ts TEXT NOT NULL DEFAULT (datetime('now')),
    onchain_status TEXT NOT NULL DEFAULT 'not_configured' CHECK(onchain_status IN ('pending','confirmed','failed','not_configured')),
    onchain_tx_hash TEXT
);

CREATE TABLE IF NOT EXISTS holdings (
    pool_id TEXT NOT NULL REFERENCES pools(id),
    symbol TEXT NOT NULL REFERENCES instruments(symbol),
    quantity INTEGER NOT NULL DEFAULT 0,
    avg_price REAL NOT NULL DEFAULT 0,
    PRIMARY KEY (pool_id, symbol)
);

CREATE TABLE IF NOT EXISTS orders (
    id TEXT PRIMARY KEY,
    pool_id TEXT NOT NULL REFERENCES pools(id),
    symbol TEXT NOT NULL REFERENCES instruments(symbol),
    side TEXT NOT NULL CHECK(side IN ('BUY','SELL')),
    order_type TEXT NOT NULL DEFAULT 'MARKET' CHECK(order_type IN ('MARKET','LIMIT')),
    quantity INTEGER NOT NULL,
    limit_price REAL,
    status TEXT NOT NULL DEFAULT 'PENDING' CHECK(status IN ('PENDING','FILLED','REJECTED','CANCELLED')),
    fill_price REAL,
    reject_reason TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    filled_at TEXT
);
