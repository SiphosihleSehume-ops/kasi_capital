const Database = require('better-sqlite3');
const fs = require('fs');
const path = require('path');
const { randomUUID } = require('crypto');
const seedInstruments = require('../data/seedInstruments');

const DB_PATH = process.env.DB_PATH || path.join(__dirname, '../../mock_jse.db');
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');

// Generic "add column if missing" migration, so an existing DB file from an
// earlier version of the app picks up new columns without a full rebuild.
// Declarative list: add an entry here whenever schema.sql gains a column on
// an existing table (new tables need no entry — CREATE TABLE IF NOT EXISTS
// handles those on its own).
const COLUMN_MIGRATIONS = [
  { table: 'contributions', column: 'onchain_status', ddl: "TEXT NOT NULL DEFAULT 'not_configured'" },
  { table: 'contributions', column: 'onchain_tx_hash', ddl: 'TEXT' },
];

function runColumnMigrations() {
  for (const { table, column, ddl } of COLUMN_MIGRATIONS) {
    const tableExists = db.prepare(
      "SELECT name FROM sqlite_master WHERE type='table' AND name = ?"
    ).get(table);
    if (!tableExists) continue; // fresh DB — schema.sql already created it with all columns

    const cols = db.prepare(`PRAGMA table_info(${table})`).all().map(c => c.name);
    if (!cols.includes(column)) {
      db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${ddl}`);
      console.log(`Migrated: added ${table}.${column}`);
    }
  }
}

function init() {
  const schema = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
  db.exec(schema);

  runColumnMigrations();

  const count = db.prepare('SELECT COUNT(*) AS c FROM instruments').get().c;
  if (count === 0) {
    const insert = db.prepare(`
      INSERT INTO instruments (symbol, name, sector, last_price, prev_close, day_open, day_high, day_low, volatility, drift, price_source)
      VALUES (@symbol, @name, @sector, @price, @price, @price, @price, @price, @volatility, @drift, 'synthetic')
    `);
    const insertMany = db.transaction((rows) => rows.forEach(r => insert.run(r)));
    insertMany(seedInstruments);
    console.log(`Seeded ${seedInstruments.length} instruments.`);
  }

  const poolCount = db.prepare('SELECT COUNT(*) AS c FROM pools').get().c;
  if (poolCount === 0) {
    db.prepare(`INSERT INTO pools (id, name, cash_balance) VALUES (?, ?, ?)`)
      .run('default-pool', 'Default Stokvel Pool', 0);
    console.log('Created default pool.');
  }
}

module.exports = { db, init, randomUUID };
