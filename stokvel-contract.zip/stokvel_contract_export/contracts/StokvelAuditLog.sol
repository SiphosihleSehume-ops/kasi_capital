// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// @title StokvelAuditLog
/// @notice A thin, deliberately non-custodial audit trail for a MoMo-based
///         stokvel investment pool. This contract does NOT hold funds and
///         does NOT move Rand, MoMo balances, or JSE shares — all of that
///         happens off-chain via MTN MoMo and the pool's broker/backend.
///
///         Its only job is to record, immutably and publicly, that a given
///         contribution was split according to the fixed allocation rule
///         below — so no organizer can quietly change the split or hide a
///         contribution after the fact. Anyone can independently verify the
///         full history of the pool from these events alone.
contract StokvelAuditLog {
    /// @notice Fixed allocation rule, expressed in basis points (1/100 of a
    ///         percent) so the whole contract can use integer math.
    ///         70.00% invested, 15.00% MTN fee, 15.00% quarterly payout.
    uint16 public constant INVEST_BPS = 7000;
    uint16 public constant MTN_FEE_BPS = 1500;
    uint16 public constant QUARTERLY_PAYOUT_BPS = 1500;
    uint16 public constant TOTAL_BPS = 10000;

    /// @notice The address permitted to log entries on behalf of the pool —
    ///         in practice, the stokvel app's backend service account. This
    ///         is intentionally a single trusted logger for the hackathon
    ///         build; see NOTES.md for the multisig/DAO upgrade path.
    address public logger;

    /// @notice Human-readable pool identifier (matches the backend's poolId).
    string public poolId;

    struct ContributionRecord {
        address loggedBy;
        string memberId;
        uint256 amountCents; // ZAR amount in cents, to avoid floating point
        uint256 investAmountCents;
        uint256 mtnFeeAmountCents;
        uint256 quarterlyPayoutAmountCents;
        uint256 timestamp;
    }

    struct PayoutRecord {
        address loggedBy;
        string memberId;
        uint256 amountCents;
        string quarterLabel; // e.g. "2026-Q3"
        uint256 timestamp;
    }

    ContributionRecord[] public contributions;
    PayoutRecord[] public payouts;

    event ContributionLogged(
        uint256 indexed index,
        string indexed memberId,
        string memberIdPlain,
        uint256 amountCents,
        uint256 investAmountCents,
        uint256 mtnFeeAmountCents,
        uint256 quarterlyPayoutAmountCents,
        uint256 timestamp
    );

    event PayoutLogged(
        uint256 indexed index,
        string indexed memberId,
        string memberIdPlain,
        uint256 amountCents,
        string quarterLabel,
        uint256 timestamp
    );

    event LoggerUpdated(address indexed previousLogger, address indexed newLogger);

    error NotLogger();
    error ZeroAmount();
    error EmptyMemberId();

    modifier onlyLogger() {
        if (msg.sender != logger) revert NotLogger();
        _;
    }

    constructor(string memory _poolId, address _logger) {
        poolId = _poolId;
        logger = _logger == address(0) ? msg.sender : _logger;
    }

    /// @notice Record that a contribution was received and split per the
    ///         fixed rule. Called by the backend immediately after a member's
    ///         MoMo payment is confirmed — the on-chain amounts are computed
    ///         here (not passed in pre-split) so the split itself is provably
    ///         enforced by this contract's own math, not just trusted from
    ///         the backend.
    /// @param memberId Off-chain member identifier (matches the backend's).
    /// @param amountCents Total contribution amount, in ZAR cents.
    function logContribution(string calldata memberId, uint256 amountCents)
        external
        onlyLogger
        returns (uint256 index)
    {
        if (amountCents == 0) revert ZeroAmount();
        if (bytes(memberId).length == 0) revert EmptyMemberId();

        uint256 investAmount = (amountCents * INVEST_BPS) / TOTAL_BPS;
        uint256 mtnFeeAmount = (amountCents * MTN_FEE_BPS) / TOTAL_BPS;
        // Remainder goes to quarterly payout so rounding dust never gets lost.
        uint256 payoutAmount = amountCents - investAmount - mtnFeeAmount;

        contributions.push(
            ContributionRecord({
                loggedBy: msg.sender,
                memberId: memberId,
                amountCents: amountCents,
                investAmountCents: investAmount,
                mtnFeeAmountCents: mtnFeeAmount,
                quarterlyPayoutAmountCents: payoutAmount,
                timestamp: block.timestamp
            })
        );
        index = contributions.length - 1;

        emit ContributionLogged(
            index,
            memberId,
            memberId,
            amountCents,
            investAmount,
            mtnFeeAmount,
            payoutAmount,
            block.timestamp
        );
    }

    /// @notice Record a quarterly payout made to a member via MoMo.
    function logPayout(string calldata memberId, uint256 amountCents, string calldata quarterLabel)
        external
        onlyLogger
        returns (uint256 index)
    {
        if (amountCents == 0) revert ZeroAmount();
        if (bytes(memberId).length == 0) revert EmptyMemberId();

        payouts.push(
            PayoutRecord({
                loggedBy: msg.sender,
                memberId: memberId,
                amountCents: amountCents,
                quarterLabel: quarterLabel,
                timestamp: block.timestamp
            })
        );
        index = payouts.length - 1;

        emit PayoutLogged(index, memberId, memberId, amountCents, quarterLabel, block.timestamp);
    }

    function contributionCount() external view returns (uint256) {
        return contributions.length;
    }

    function payoutCount() external view returns (uint256) {
        return payouts.length;
    }

    /// @notice Rotate the backend service account allowed to log entries.
    ///         Left as owner-less/single-key for the hackathon; a production
    ///         version should gate this behind a multisig of pool members.
    function updateLogger(address newLogger) external onlyLogger {
        emit LoggerUpdated(logger, newLogger);
        logger = newLogger;
    }
}
