# StokvelAuditLog — thin on-chain audit trail

A minimal Solidity contract for MoMo Stokvel Invest. **It does not hold, move, or
custody any funds.** All real money movement — MoMo payments, JSE trades,
quarterly payouts — happens off-chain through the app's Express backend and
regulated partners. This contract's only job is to publicly and immutably log
that a contribution was split according to the fixed rule below, so:

- No organizer can quietly change the split after the fact.
- Anyone (a member, an auditor, a judge) can independently verify the full
  history of the pool's allocation from the chain alone.

## The fixed rule

70% invested in JSE stocks, 15% MTN infrastructure fee, 15% quarterly member
payout — set as compile-time constants (`INVEST_BPS`, `MTN_FEE_BPS`,
`QUARTERLY_PAYOUT_BPS`). **Changing the split means deploying a new contract**,
deliberately — that makes any change visible as a new contract address rather
than a silent update to existing logic.

## Honest limitation: this is a logging layer, not a decentralization layer

Only one address — the `logger` (in practice, the backend's service account)
— is allowed to call `logContribution`/`logPayout`. That means:

- **Reading** the log is fully decentralized and trustless — anyone can query
  the chain directly and get the true history.
- **Writing** to the log is currently centralized to one trusted key. A
  dishonest backend could simply *not call* `logContribution` for a real
  contribution, or log a different amount than was actually received — the
  contract can't detect that on its own, because it has no independent way to
  observe the real-world MoMo/JSE transaction.

This is an intentional, disclosed trade-off for a hackathon-scope build: it
still solves the actual problem (the *split rule* can't be silently changed,
and every logged event is permanent and public), but it is not equivalent to
a fully trustless system. A production version would need either (a) an
oracle/attestation from MTN's own systems, or (b) multiple independent
parties (e.g. a subset of stokvel members) required to co-sign each log entry.

## Setup

```bash
npm install
cp .env.example .env
# add DEPLOYER_PRIVATE_KEY (fund it with test MATIC from a Polygon Amoy faucet)
```

## Verifying the contract logic

Hardhat 3's built-in compiler manager needs network access to
`binaries.soliditylang.org` to fetch the exact solc version. If that's
blocked in your environment, compile directly with the `solc` npm package
instead:

```bash
npx solcjs --bin --abi --optimize -o build contracts/StokvelAuditLog.sol
```

The contract's logic (70/15/15 split math, rounding-remainder handling,
access control, input validation, payout logging, logger rotation) has been
verified end-to-end against a local in-memory EVM — every check passes:
correct split constants, correct cent-level math, no rounding dust lost,
reverts on non-logger callers / zero amounts / empty member IDs, and correct
event emission.

## Deploying to Polygon Amoy

```bash
npx hardhat run scripts/deploy.js --network amoy
```

This prints the deployed contract address — save it, you'll need it for the
backend integration (see `CONTRACT_INTEGRATION.md` in the backend repo).

## Contract interface

- `logContribution(string memberId, uint256 amountCents)` — computes and
  logs the 70/15/15 split for a contribution, in ZAR cents. Logger-only.
- `logPayout(string memberId, uint256 amountCents, string quarterLabel)` —
  logs a quarterly payout made to a member. Logger-only.
- `contributions(uint256 index)` / `contributionCount()` — read the full
  on-chain contribution history.
- `payouts(uint256 index)` / `payoutCount()` — read the full payout history.
- `updateLogger(address newLogger)` — rotates the backend key allowed to log
  entries. Logger-only.
