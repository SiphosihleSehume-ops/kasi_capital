import { expect } from 'chai';
import hre from 'hardhat';
import { anyValue } from '@nomicfoundation/hardhat-ethers-chai-matchers/withArgs';

describe('StokvelAuditLog', function () {
  async function deployFixture() {
    const { ethers } = await hre.network.connect();
    const [owner, logger, other] = await ethers.getSigners();
    const Factory = await ethers.getContractFactory('StokvelAuditLog');
    const contract = await Factory.deploy('default-pool', logger.address);
    await contract.waitForDeployment();
    return { contract, owner, logger, other, ethers };
  }

  it('sets the fixed 70/15/15 split at deployment', async function () {
    const { contract } = await deployFixture();
    expect(await contract.INVEST_BPS()).to.equal(7000n);
    expect(await contract.MTN_FEE_BPS()).to.equal(1500n);
    expect(await contract.QUARTERLY_PAYOUT_BPS()).to.equal(1500n);
  });

  it('defaults logger to deployer when zero address is passed', async function () {
    const { ethers, owner } = await deployFixture();
    const Factory = await ethers.getContractFactory('StokvelAuditLog');
    const contract = await Factory.deploy('pool-2', '0x0000000000000000000000000000000000000000');
    await contract.waitForDeployment();
    expect(await contract.logger()).to.equal(owner.address);
  });

  it('splits a contribution correctly and emits an event', async function () {
    const { contract, logger } = await deployFixture();
    // R1,000.00 = 100,000 cents
    const amountCents = 100_000n;

    await expect(contract.connect(logger).logContribution('member-1', amountCents))
      .to.emit(contract, 'ContributionLogged')
      .withArgs(0n, 'member-1', 'member-1', amountCents, 70_000n, 15_000n, 15_000n, anyValue);

    const record = await contract.contributions(0);
    expect(record.amountCents).to.equal(amountCents);
    expect(record.investAmountCents).to.equal(70_000n);
    expect(record.mtnFeeAmountCents).to.equal(15_000n);
    expect(record.quarterlyPayoutAmountCents).to.equal(15_000n);
  });

  it('gives rounding remainder to the quarterly payout so no cents are lost', async function () {
    const { contract, logger } = await deployFixture();
    // 1 cent contribution: 70% of 1 = 0 (floor), 15% of 1 = 0 (floor), remainder = 1
    await contract.connect(logger).logContribution('member-1', 1n);
    const record = await contract.contributions(0);
    expect(record.investAmountCents + record.mtnFeeAmountCents + record.quarterlyPayoutAmountCents).to.equal(1n);
    expect(record.quarterlyPayoutAmountCents).to.equal(1n);
  });

  it('rejects contributions from a non-logger address', async function () {
    const { contract, other } = await deployFixture();
    await expect(contract.connect(other).logContribution('member-1', 1000n)).to.be.revertedWithCustomError(
      contract,
      'NotLogger'
    );
  });

  it('rejects a zero-amount contribution', async function () {
    const { contract, logger } = await deployFixture();
    await expect(contract.connect(logger).logContribution('member-1', 0n)).to.be.revertedWithCustomError(
      contract,
      'ZeroAmount'
    );
  });

  it('rejects an empty member id', async function () {
    const { contract, logger } = await deployFixture();
    await expect(contract.connect(logger).logContribution('', 1000n)).to.be.revertedWithCustomError(
      contract,
      'EmptyMemberId'
    );
  });

  it('logs a quarterly payout', async function () {
    const { contract, logger } = await deployFixture();
    await expect(contract.connect(logger).logPayout('member-1', 5000n, '2026-Q3'))
      .to.emit(contract, 'PayoutLogged')
      .withArgs(0n, 'member-1', 'member-1', 5000n, '2026-Q3', anyValue);

    expect(await contract.payoutCount()).to.equal(1n);
  });

  it('only the logger can rotate the logger address', async function () {
    const { contract, logger, other } = await deployFixture();
    await expect(contract.connect(other).updateLogger(other.address)).to.be.revertedWithCustomError(
      contract,
      'NotLogger'
    );
    await expect(contract.connect(logger).updateLogger(other.address))
      .to.emit(contract, 'LoggerUpdated')
      .withArgs(logger.address, other.address);
    expect(await contract.logger()).to.equal(other.address);
  });

  it('tracks contribution and payout counts', async function () {
    const { contract, logger } = await deployFixture();
    expect(await contract.contributionCount()).to.equal(0n);
    await contract.connect(logger).logContribution('member-1', 1000n);
    await contract.connect(logger).logContribution('member-2', 2000n);
    expect(await contract.contributionCount()).to.equal(2n);
  });
});
