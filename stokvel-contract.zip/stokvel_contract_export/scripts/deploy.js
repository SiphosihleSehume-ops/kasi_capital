import hre from 'hardhat';

// Deploys StokvelAuditLog to whichever network is passed via --network.
// The deployer address becomes the initial `logger` (the backend's key in
// production); pass DEPLOYER_PRIVATE_KEY and POLYGON_AMOY_RPC_URL via .env.
async function main() {
  const { ethers } = await hre.network.connect();
  const [deployer] = await ethers.getSigners();

  const poolId = process.env.POOL_ID || 'default-pool';

  console.log(`Deploying StokvelAuditLog for pool "${poolId}"`);
  console.log(`Deployer / initial logger: ${deployer.address}`);

  const Factory = await ethers.getContractFactory('StokvelAuditLog');
  const contract = await Factory.deploy(poolId, deployer.address);
  await contract.waitForDeployment();

  const address = await contract.getAddress();
  console.log(`StokvelAuditLog deployed at: ${address}`);
  console.log(`Verify allocation rule: invest 70%, mtnFee 15%, quarterlyPayout 15% (fixed at compile time)`);
}

main().catch((err) => {
  console.error(err);
  process.exitCode = 1;
});
