/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        paper: '#FAF6EF',
        ink: '#1F2A24',
        'ink-soft': '#4A5751',
        forest: {
          DEFAULT: '#2F5D50',
          dark: '#1F4137',
          light: '#5C8577',
        },
        ochre: {
          DEFAULT: '#C98A3C',
          dark: '#A66E2A',
          light: '#E4B579',
        },
        brick: {
          DEFAULT: '#A34A38',
          light: '#C97B69',
        },
        line: '#DDD5C4',
      },
      fontFamily: {
        display: ['"Fraunces"', 'ui-serif', 'Georgia', 'serif'],
        sans: ['"Inter"', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
}
