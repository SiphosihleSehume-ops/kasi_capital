# Umlomo — MoMo Stokvel Invest frontend

React (Vite) + Tailwind CSS frontend for the pooled stokvel investment app.
"Umlomo" is a placeholder name — swap it in `src/components/AppShell.jsx`.

## Design approach

Built around a ledger/passbook metaphor rather than a typical SaaS dashboard:
warm paper background, forest green + ochre + brick accents, a serif
(Fraunces) for headings paired with Inter for data. The goal, per the
project's own pitch, is something a non-technical member — "if our mothers
can't use it, we've failed" — can navigate without any crypto or fintech
jargon. Blockchain/audit-log features are present but kept quiet, not
front-and-center.

## Setup

```bash
npm install
cp .env.example .env   # point VITE_API_URL at your backend
npm run dev
```

Requires the backend (`mock-jse-api`) running — default expected at
`http://localhost:4000`.

## Pages

- **Overview** — pool total value, cash/invested/P&L breakdown, the fixed
  70/15/15 allocation split, recent contributions, current holdings.
- **Market** — all JSE instruments with live price chart, honestly labeled
  "Live" (real Twelve Data) vs. "Simulated" (random-walk fallback).
- **Trade** — place buy/sell orders on the pool's behalf, record member
  contributions, view order history.
- **Members** — each member's total contribution and share of the pool.
- **Ledger & audit** — the fixed allocation rule, and each contribution's
  real on-chain status (pending/confirmed/failed/off-chain-only) with a link
  to its transaction on Polygon Amoy's explorer once confirmed.

## Known gaps

- No real user accounts/auth — anyone can place orders or record
  contributions for any member. Fine for a demo, not for production.
- Fractional share quantities aren't supported yet (whole shares only),
  though the pitch mentions "investing from R10" — would need a form/backend
  change to support decimals.
- No wallet-connect flow — the smart contract is written to be called only
  by the backend's own service account, not directly by members' wallets,
  so there's deliberately no MetaMask/WalletConnect integration here.
