import { Routes, Route } from 'react-router-dom';
import AppShell from './components/AppShell';
import Overview from './pages/Overview';
import Market from './pages/Market';
import Trade from './pages/Trade';
import Members from './pages/Members';
import LedgerPage from './pages/LedgerPage';
import { useStokvelData } from './hooks/useStokvelData';

export default function App() {
  const data = useStokvelData();

  return (
    <AppShell poolName={data.portfolio?.poolName}>
      <Routes>
        <Route path="/" element={<Overview data={data} />} />
        <Route path="/market" element={<Market data={data} />} />
        <Route path="/trade" element={<Trade data={data} />} />
        <Route path="/members" element={<Members data={data} />} />
        <Route path="/ledger" element={<LedgerPage data={data} />} />
      </Routes>
    </AppShell>
  );
}
