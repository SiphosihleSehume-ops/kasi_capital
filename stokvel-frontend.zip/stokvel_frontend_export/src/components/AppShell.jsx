import { NavLink } from 'react-router-dom';
import { BookText, PieChart, ArrowLeftRight, Users, ShieldCheck } from 'lucide-react';

const navItems = [
  { to: '/', label: 'Overview', mobileLabel: 'Overview', icon: BookText, end: true },
  { to: '/market', label: 'Market', mobileLabel: 'Market', icon: PieChart },
  { to: '/trade', label: 'Trade', mobileLabel: 'Trade', icon: ArrowLeftRight },
  { to: '/members', label: 'Members', mobileLabel: 'Members', icon: Users },
  { to: '/ledger', label: 'Ledger & audit', mobileLabel: 'Ledger', icon: ShieldCheck },
];

export default function AppShell({ children, poolName }) {
  return (
    <div className="min-h-screen bg-paper text-ink">
      <header className="border-b border-line">
        <div className="mx-auto flex max-w-6xl items-baseline justify-between px-6 py-6">
          <div>
            <p className="font-display text-2xl text-forest-dark">Umlomo</p>
            <p className="text-sm text-ink-soft">{poolName || 'Community investment book'}</p>
          </div>
          <nav className="hidden gap-6 sm:flex">
            {navItems.map(({ to, label, icon: Icon, end }) => (
              <NavLink
                key={to}
                to={to}
                end={end}
                className={({ isActive }) =>
                  `flex items-center gap-2 border-b-2 pb-1 text-sm transition-colors ${
                    isActive
                      ? 'border-forest text-forest-dark'
                      : 'border-transparent text-ink-soft hover:text-ink'
                  }`
                }
              >
                <Icon size={16} strokeWidth={2} />
                {label}
              </NavLink>
            ))}
          </nav>
        </div>
        {/* mobile nav */}
        <nav className="grid grid-cols-5 gap-1 border-t border-line px-2 py-2 sm:hidden">
          {navItems.map(({ to, mobileLabel, icon: Icon, end }) => (
            <NavLink
              key={to}
              to={to}
              end={end}
              className={({ isActive }) =>
                `flex flex-col items-center gap-1 rounded px-1 py-1.5 text-[11px] leading-tight ${
                  isActive ? 'bg-forest text-paper' : 'text-ink-soft'
                }`
              }
            >
              <Icon size={16} />
              {mobileLabel}
            </NavLink>
          ))}
        </nav>
      </header>
      <main className="mx-auto max-w-6xl px-6 py-10">{children}</main>
      <footer className="mx-auto max-w-6xl px-6 py-10 text-xs text-ink-soft">
        Demo build — prices and figures are for a hackathon simulation, not real financial advice.
      </footer>
    </div>
  );
}
