export default function StatLine({ label, value, sub, tone = 'default', size = 'md' }) {
  const toneClass = {
    default: 'text-ink',
    positive: 'text-forest-dark',
    negative: 'text-brick',
  }[tone];

  const sizeClass = {
    lg: 'text-4xl sm:text-5xl',
    md: 'text-2xl',
    sm: 'text-lg',
  }[size];

  return (
    <div>
      <p className="text-sm text-ink-soft">{label}</p>
      <p className={`font-display num-tabular ${sizeClass} ${toneClass}`}>{value}</p>
      {sub && <p className="mt-1 text-sm text-ink-soft">{sub}</p>}
    </div>
  );
}
