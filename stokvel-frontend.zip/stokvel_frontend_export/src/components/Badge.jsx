const tones = {
  live: 'bg-forest/10 text-forest-dark',
  synthetic: 'bg-ochre/15 text-ochre-dark',
  filled: 'bg-forest/10 text-forest-dark',
  pending: 'bg-ochre/15 text-ochre-dark',
  rejected: 'bg-brick/10 text-brick',
  neutral: 'bg-ink/5 text-ink-soft',
};

export default function Badge({ tone = 'neutral', children }) {
  return (
    <span className={`inline-flex items-center rounded px-2 py-0.5 text-xs ${tones[tone] || tones.neutral}`}>
      {children}
    </span>
  );
}
