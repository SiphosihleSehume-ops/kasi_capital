import { useEffect, useState } from 'react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { api } from '../lib/api';
import { formatZAR, formatDateTime } from '../lib/format';

export default function PriceChart({ symbol, name }) {
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    api.getHistory(symbol, 60).then((res) => {
      if (!cancelled) {
        setHistory(res.history.map((h) => ({ ...h, priceNum: h.price })));
        setLoading(false);
      }
    });
    return () => { cancelled = true; };
  }, [symbol]);

  return (
    <div className="rounded border border-line p-6">
      <div className="mb-4 flex items-baseline justify-between">
        <div>
          <p className="text-sm text-ink-soft">{name}</p>
          <p className="font-display text-2xl">{symbol}</p>
        </div>
      </div>
      {loading ? (
        <p className="py-16 text-center text-sm text-ink-soft">Loading chart…</p>
      ) : history.length < 2 ? (
        <p className="py-16 text-center text-sm text-ink-soft">Not enough history yet — check back after a few price ticks.</p>
      ) : (
        <ResponsiveContainer width="100%" height={220}>
          <AreaChart data={history} margin={{ top: 4, right: 8, left: 0, bottom: 0 }}>
            <defs>
              <linearGradient id="priceFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#2F5D50" stopOpacity={0.25} />
                <stop offset="100%" stopColor="#2F5D50" stopOpacity={0} />
              </linearGradient>
            </defs>
            <XAxis dataKey="ts" hide />
            <YAxis domain={['auto', 'auto']} hide />
            <Tooltip
              formatter={(value) => [formatZAR(value), 'Price']}
              labelFormatter={(label) => formatDateTime(label)}
              contentStyle={{ background: '#FAF6EF', border: '1px solid #DDD5C4', borderRadius: 4, fontSize: 13 }}
            />
            <Area type="monotone" dataKey="priceNum" stroke="#2F5D50" strokeWidth={2} fill="url(#priceFill)" />
          </AreaChart>
        </ResponsiveContainer>
      )}
    </div>
  );
}
