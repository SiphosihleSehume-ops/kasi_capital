export function LedgerSection({ title, action, children }) {
  return (
    <section className="border-t border-line pt-6">
      <div className="mb-4 flex items-center justify-between">
        <h2 className="font-display text-xl text-ink">{title}</h2>
        {action}
      </div>
      {children}
    </section>
  );
}

export function LedgerTable({ columns, children }) {
  return (
    <table className="w-full border-collapse text-sm">
      <thead>
        <tr className="border-b border-line text-left text-ink-soft">
          {columns.map((col) => (
            <th key={col} className="pb-2 pr-4 font-normal">{col}</th>
          ))}
        </tr>
      </thead>
      <tbody>{children}</tbody>
    </table>
  );
}

export function LedgerRow({ children }) {
  return <tr className="border-b border-line/60 last:border-none">{children}</tr>;
}

export function LedgerCell({ children, className = '', ...rest }) {
  return <td className={`py-3 pr-4 ${className}`} {...rest}>{children}</td>;
}
