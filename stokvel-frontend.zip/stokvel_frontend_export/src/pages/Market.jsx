import { useState } from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';
import { LedgerSection, LedgerTable, LedgerRow, LedgerCell } from '../components/Ledger';
import Badge from '../components/Badge';
import PriceChart from '../components/PriceChart';
import { formatZAR, formatPct } from '../lib/format';

export default function Market({ data }) {
  const { instruments, loading } = data;
  const [selected, setSelected] = useState(null);

  if (loading) return <p className="text-ink-soft">Reading today's prices…</p>;

  const active = selected || instruments[0]?.symbol;
  const activeInstrument = instruments.find((i) => i.symbol === active);

  return (
    <div className="space-y-10">
      <div>
        <h1 className="font-display text-3xl">Market</h1>
        <p className="mt-1 text-sm text-ink-soft">
          JSE-listed instruments the pool can invest in. Prices marked "live" come from real market data;
          "simulated" prices move on a random-walk model for demo purposes.
        </p>
      </div>

      {activeInstrument && <PriceChart symbol={activeInstrument.symbol} name={activeInstrument.name} />}

      <LedgerSection title="All instruments">
        <LedgerTable columns={['Symbol', 'Name', 'Sector', 'Price', 'Change', 'Source']}>
          {instruments.map((inst) => (
            <LedgerRow key={inst.symbol}>
              <LedgerCell
                className="cursor-pointer font-medium text-forest-dark hover:underline"
                onClick={() => setSelected(inst.symbol)}
              >
                {inst.symbol}
              </LedgerCell>
              <LedgerCell>{inst.name}</LedgerCell>
              <LedgerCell className="text-ink-soft">{inst.sector}</LedgerCell>
              <LedgerCell className="num-tabular">{formatZAR(inst.price)}</LedgerCell>
              <LedgerCell>
                <span className={`flex items-center gap-1 ${inst.change >= 0 ? 'text-forest-dark' : 'text-brick'}`}>
                  {inst.change >= 0 ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
                  {formatPct(inst.changePct, { signed: true })}
                </span>
              </LedgerCell>
              <LedgerCell>
                <Badge tone={inst.priceSource === 'twelve_data' ? 'live' : 'synthetic'}>
                  {inst.priceSource === 'twelve_data' ? 'Live' : 'Simulated'}
                </Badge>
              </LedgerCell>
            </LedgerRow>
          ))}
        </LedgerTable>
      </LedgerSection>
    </div>
  );
}
