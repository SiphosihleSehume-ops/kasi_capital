import { ShieldCheck, ExternalLink } from 'lucide-react';
import { LedgerSection, LedgerTable, LedgerRow, LedgerCell } from '../components/Ledger';
import Badge from '../components/Badge';
import { formatZAR, formatDateTime, ALLOCATION_RULE } from '../lib/format';

const AMOY_EXPLORER = 'https://amoy.polygonscan.com/tx/';

const statusBadge = {
  confirmed: { tone: 'filled', label: 'Confirmed on-chain' },
  pending: { tone: 'pending', label: 'Pending' },
  failed: { tone: 'rejected', label: 'Chain log failed' },
  not_configured: { tone: 'neutral', label: 'Off-chain only' },
};

export default function LedgerPage({ data }) {
  const { contributions } = data;

  const chainConfigured = contributions.some((c) => c.onchain_status !== 'not_configured');

  return (
    <div className="space-y-12">
      <div>
        <h1 className="font-display text-3xl">Ledger &amp; audit</h1>
        <p className="mt-1 text-sm text-ink-soft">
          The rules below are fixed and logged publicly, so no single person can quietly change how the pool's
          money is split.
        </p>
      </div>

      <div className="flex items-start gap-3 rounded border border-forest/20 bg-forest/5 p-4 text-sm">
        <ShieldCheck size={18} className="mt-0.5 shrink-0 text-forest-dark" />
        <div>
          <p className="font-medium text-forest-dark">Allocation rule, recorded on-chain</p>
          <p className="mt-1 text-ink-soft">
            A lightweight smart contract on Polygon Amoy logs every contribution and its split as a public event —
            it doesn't move the money itself (that happens through MTN MoMo and the pool's broker), but it means
            the split percentages below can be independently verified by anyone, forever. Only the app's backend
            is currently allowed to write new entries; anyone can read the full history.
          </p>
        </div>
      </div>

      <LedgerSection title="Fixed split, per contribution">
        <LedgerTable columns={['Destination', 'Percentage', 'What it funds']}>
          <LedgerRow>
            <LedgerCell className="font-medium">Market investment</LedgerCell>
            <LedgerCell className="num-tabular">{(ALLOCATION_RULE.invest * 100).toFixed(0)}%</LedgerCell>
            <LedgerCell className="text-ink-soft">Bought into JSE stocks/ETFs on the pool's behalf</LedgerCell>
          </LedgerRow>
          <LedgerRow>
            <LedgerCell className="font-medium">MTN infrastructure fee</LedgerCell>
            <LedgerCell className="num-tabular">{(ALLOCATION_RULE.mtnFee * 100).toFixed(0)}%</LedgerCell>
            <LedgerCell className="text-ink-soft">Covers MoMo payment rails and agent network costs</LedgerCell>
          </LedgerRow>
          <LedgerRow>
            <LedgerCell className="font-medium">Quarterly member payout</LedgerCell>
            <LedgerCell className="num-tabular">{(ALLOCATION_RULE.quarterlyPayout * 100).toFixed(0)}%</LedgerCell>
            <LedgerCell className="text-ink-soft">Set aside and paid back to members every quarter</LedgerCell>
          </LedgerRow>
        </LedgerTable>
      </LedgerSection>

      <LedgerSection title="Contributions & their on-chain status">
        {!chainConfigured && (
          <div className="mb-4 rounded border border-dashed border-line px-4 py-3 text-sm text-ink-soft">
            This deployment isn't connected to a live contract yet, so contributions are recorded off-chain only.
            Once <code className="text-xs">AUDIT_LOG_CONTRACT_ADDRESS</code> is set on the backend, new
            contributions will show a real transaction hash here, linked to{' '}
            <a
              href="https://amoy.polygonscan.com"
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1 text-forest-dark underline"
            >
              Polygon Amoy's explorer <ExternalLink size={12} />
            </a>
            .
          </div>
        )}
        {contributions.length === 0 ? (
          <p className="text-sm text-ink-soft">No contributions recorded yet.</p>
        ) : (
          <LedgerTable columns={['Member', 'Amount', 'Chain status', 'Recorded']}>
            {contributions.slice(0, 15).map((c) => {
              const badge = statusBadge[c.onchain_status] || statusBadge.not_configured;
              return (
                <LedgerRow key={c.id}>
                  <LedgerCell>{c.member_name || c.member_id}</LedgerCell>
                  <LedgerCell className="num-tabular">{formatZAR(c.amount)}</LedgerCell>
                  <LedgerCell>
                    <Badge tone={badge.tone}>{badge.label}</Badge>
                    {c.onchain_tx_hash && (
                      <a
                        href={`${AMOY_EXPLORER}${c.onchain_tx_hash}`}
                        target="_blank"
                        rel="noreferrer"
                        className="ml-2 inline-flex items-center gap-1 text-xs text-forest-dark underline"
                      >
                        View tx <ExternalLink size={10} />
                      </a>
                    )}
                  </LedgerCell>
                  <LedgerCell className="text-ink-soft">{formatDateTime(c.ts)}</LedgerCell>
                </LedgerRow>
              );
            })}
          </LedgerTable>
        )}
      </LedgerSection>
    </div>
  );
}
