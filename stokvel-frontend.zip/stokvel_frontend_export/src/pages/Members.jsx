import { useMemo } from 'react';
import { LedgerSection, LedgerTable, LedgerRow, LedgerCell } from '../components/Ledger';
import { formatZAR, formatDate } from '../lib/format';

export default function Members({ data }) {
  const { contributions, portfolio } = data;

  const byMember = useMemo(() => {
    const map = new Map();
    for (const c of contributions) {
      const key = c.member_id;
      const existing = map.get(key) || { memberId: key, name: c.member_name || key, total: 0, count: 0, last: c.ts };
      existing.total += c.amount;
      existing.count += 1;
      if (new Date(c.ts) > new Date(existing.last)) existing.last = c.ts;
      map.set(key, existing);
    }
    return Array.from(map.values()).sort((a, b) => b.total - a.total);
  }, [contributions]);

  const totalContributed = portfolio?.totalContributed ?? 0;

  return (
    <div className="space-y-10">
      <div>
        <h1 className="font-display text-3xl">Members</h1>
        <p className="mt-1 text-sm text-ink-soft">
          Every member's share of the pool is proportional to what they've put in — visible to everyone, always.
        </p>
      </div>

      <LedgerSection title={`${byMember.length} contributing members`}>
        {byMember.length === 0 ? (
          <p className="text-sm text-ink-soft">No members have contributed yet.</p>
        ) : (
          <LedgerTable columns={['Member', 'Total contributed', 'Share of pool', 'Payments made', 'Last contribution']}>
            {byMember.map((m) => (
              <LedgerRow key={m.memberId}>
                <LedgerCell className="font-medium">{m.name}</LedgerCell>
                <LedgerCell className="num-tabular">{formatZAR(m.total)}</LedgerCell>
                <LedgerCell className="num-tabular">
                  {totalContributed ? ((m.total / totalContributed) * 100).toFixed(1) : '0.0'}%
                </LedgerCell>
                <LedgerCell className="num-tabular">{m.count}</LedgerCell>
                <LedgerCell className="text-ink-soft">{formatDate(m.last)}</LedgerCell>
              </LedgerRow>
            ))}
          </LedgerTable>
        )}
      </LedgerSection>
    </div>
  );
}
