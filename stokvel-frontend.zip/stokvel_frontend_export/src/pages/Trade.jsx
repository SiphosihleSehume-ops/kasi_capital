import { useState } from 'react';
import { api } from '../lib/api';
import { LedgerSection, LedgerTable, LedgerRow, LedgerCell } from '../components/Ledger';
import Badge from '../components/Badge';
import { formatZAR, formatDateTime } from '../lib/format';

const statusTone = { FILLED: 'filled', PENDING: 'pending', REJECTED: 'rejected' };

export default function Trade({ data }) {
  const { instruments, orders, portfolio, poolId, refresh } = data;
  const [symbol, setSymbol] = useState('');
  const [side, setSide] = useState('BUY');
  const [quantity, setQuantity] = useState('');
  const [placing, setPlacing] = useState(false);
  const [feedback, setFeedback] = useState(null);

  const [contribMember, setContribMember] = useState('');
  const [contribAmount, setContribAmount] = useState('');
  const [contributing, setContributing] = useState(false);
  const [contribFeedback, setContribFeedback] = useState(null);

  async function handleOrder(e) {
    e.preventDefault();
    if (!symbol || !quantity) return;
    setPlacing(true);
    setFeedback(null);
    try {
      const order = await api.placeOrder({
        poolId,
        symbol,
        side,
        quantity: parseInt(quantity, 10),
        orderType: 'MARKET',
      });
      setFeedback(
        order.status === 'FILLED'
          ? { tone: 'positive', text: `Filled: ${side === 'BUY' ? 'bought' : 'sold'} ${quantity} ${symbol} at ${formatZAR(order.fill_price)}.` }
          : { tone: 'negative', text: order.reject_reason || 'Order was rejected.' }
      );
      setQuantity('');
      refresh();
    } catch (err) {
      setFeedback({ tone: 'negative', text: err.message });
    } finally {
      setPlacing(false);
    }
  }

  async function handleContribute(e) {
    e.preventDefault();
    if (!contribMember || !contribAmount) return;
    setContributing(true);
    setContribFeedback(null);
    try {
      await api.contribute(poolId, { memberId: contribMember, memberName: contribMember, amount: parseFloat(contribAmount) });
      setContribFeedback({ tone: 'positive', text: `${formatZAR(parseFloat(contribAmount))} added to the pool.` });
      setContribMember('');
      setContribAmount('');
      refresh();
    } catch (err) {
      setContribFeedback({ tone: 'negative', text: err.message });
    } finally {
      setContributing(false);
    }
  }

  return (
    <div className="space-y-12">
      <div>
        <h1 className="font-display text-3xl">Trade</h1>
        <p className="mt-1 text-sm text-ink-soft">
          Place orders on behalf of the pool, or record a member's contribution.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-10 lg:grid-cols-2">
        {/* Order form */}
        <form onSubmit={handleOrder} className="space-y-4 rounded border border-line p-6">
          <h2 className="font-display text-lg">Place an order</h2>
          <p className="text-sm text-ink-soft">
            Cash available: <span className="num-tabular font-medium text-ink">{formatZAR(portfolio?.cashBalance ?? 0)}</span>
          </p>

          <div className="flex gap-2">
            {['BUY', 'SELL'].map((s) => (
              <button
                type="button"
                key={s}
                onClick={() => setSide(s)}
                className={`flex-1 rounded border px-4 py-2 text-sm font-medium transition-colors ${
                  side === s ? 'border-forest bg-forest text-paper' : 'border-line text-ink-soft hover:border-forest'
                }`}
              >
                {s === 'BUY' ? 'Buy' : 'Sell'}
              </button>
            ))}
          </div>

          <label className="block text-sm">
            <span className="mb-1 block text-ink-soft">Instrument</span>
            <select
              value={symbol}
              onChange={(e) => setSymbol(e.target.value)}
              className="w-full rounded border border-line bg-paper px-3 py-2 outline-none focus:border-forest"
              required
            >
              <option value="" disabled>Choose a symbol</option>
              {instruments.map((i) => (
                <option key={i.symbol} value={i.symbol}>{i.symbol} — {i.name} ({formatZAR(i.price)})</option>
              ))}
            </select>
          </label>

          <label className="block text-sm">
            <span className="mb-1 block text-ink-soft">Quantity (shares)</span>
            <input
              type="number"
              min="1"
              step="1"
              value={quantity}
              onChange={(e) => setQuantity(e.target.value)}
              className="w-full rounded border border-line bg-paper px-3 py-2 outline-none focus:border-forest"
              required
            />
          </label>

          <button
            type="submit"
            disabled={placing}
            className="w-full rounded bg-forest px-4 py-2.5 text-sm font-medium text-paper transition-colors hover:bg-forest-dark disabled:opacity-50"
          >
            {placing ? 'Placing order…' : `Place ${side === 'BUY' ? 'buy' : 'sell'} order`}
          </button>

          {feedback && (
            <p className={`text-sm ${feedback.tone === 'positive' ? 'text-forest-dark' : 'text-brick'}`}>
              {feedback.text}
            </p>
          )}
        </form>

        {/* Contribution form */}
        <form onSubmit={handleContribute} className="space-y-4 rounded border border-line p-6">
          <h2 className="font-display text-lg">Record a contribution</h2>
          <p className="text-sm text-ink-soft">Add a member's payment into the pool's cash balance.</p>

          <label className="block text-sm">
            <span className="mb-1 block text-ink-soft">Member name</span>
            <input
              type="text"
              value={contribMember}
              onChange={(e) => setContribMember(e.target.value)}
              className="w-full rounded border border-line bg-paper px-3 py-2 outline-none focus:border-forest"
              placeholder="e.g. Thandi Nkosi"
              required
            />
          </label>

          <label className="block text-sm">
            <span className="mb-1 block text-ink-soft">Amount (ZAR)</span>
            <input
              type="number"
              min="1"
              step="0.01"
              value={contribAmount}
              onChange={(e) => setContribAmount(e.target.value)}
              className="w-full rounded border border-line bg-paper px-3 py-2 outline-none focus:border-forest"
              placeholder="500"
              required
            />
          </label>

          <button
            type="submit"
            disabled={contributing}
            className="w-full rounded bg-ochre px-4 py-2.5 text-sm font-medium text-paper transition-colors hover:bg-ochre-dark disabled:opacity-50"
          >
            {contributing ? 'Recording…' : 'Add contribution'}
          </button>

          {contribFeedback && (
            <p className={`text-sm ${contribFeedback.tone === 'positive' ? 'text-forest-dark' : 'text-brick'}`}>
              {contribFeedback.text}
            </p>
          )}
        </form>
      </div>

      <LedgerSection title="Order history">
        {orders.length === 0 ? (
          <p className="text-sm text-ink-soft">No orders placed yet.</p>
        ) : (
          <LedgerTable columns={['Symbol', 'Side', 'Qty', 'Fill price', 'Status', 'Placed']}>
            {orders.map((o) => (
              <LedgerRow key={o.id}>
                <LedgerCell className="font-medium">{o.symbol}</LedgerCell>
                <LedgerCell>{o.side}</LedgerCell>
                <LedgerCell className="num-tabular">{o.quantity}</LedgerCell>
                <LedgerCell className="num-tabular">{o.fill_price ? formatZAR(o.fill_price) : '—'}</LedgerCell>
                <LedgerCell>
                  <Badge tone={statusTone[o.status]}>{o.status}</Badge>
                  {o.reject_reason && <span className="ml-2 text-xs text-ink-soft">{o.reject_reason}</span>}
                </LedgerCell>
                <LedgerCell className="text-ink-soft">{formatDateTime(o.created_at)}</LedgerCell>
              </LedgerRow>
            ))}
          </LedgerTable>
        )}
      </LedgerSection>
    </div>
  );
}
