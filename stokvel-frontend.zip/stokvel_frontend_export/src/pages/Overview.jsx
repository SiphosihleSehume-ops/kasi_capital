import { useMemo } from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';
import StatLine from '../components/StatLine';
import { LedgerSection, LedgerTable, LedgerRow, LedgerCell } from '../components/Ledger';
import Badge from '../components/Badge';
import { formatZAR, formatPct, formatDate, splitContribution, ALLOCATION_RULE } from '../lib/format';

export default function Overview({ data }) {
  const { portfolio, contributions, loading, error } = data;

  const totalPnl = useMemo(() => {
    if (!portfolio) return 0;
    return portfolio.holdings.reduce((sum, h) => sum + h.unrealizedPnl, 0);
  }, [portfolio]);

  const totalContributed = portfolio?.totalContributed ?? 0;
  const totalValue = portfolio?.totalValue ?? 0;
  const overallReturn = totalContributed ? ((totalValue - totalContributed) / totalContributed) * 100 : 0;

  if (loading) return <p className="text-ink-soft">Opening the ledger…</p>;
  if (error) {
    return (
      <div className="rounded border border-brick/30 bg-brick/5 p-6 text-brick">
        <p className="font-medium">Can't reach the pool's server.</p>
        <p className="mt-1 text-sm">{error} — check that the API is running.</p>
      </div>
    );
  }

  const recentContributions = contributions.slice(0, 5);
  const split = splitContribution(totalContributed);

  return (
    <div className="space-y-12">
      {/* Hero */}
      <section>
        <p className="text-sm text-ink-soft">Total pool value</p>
        <p className="font-display num-tabular text-5xl text-ink sm:text-6xl">
          {formatZAR(totalValue, { decimals: 0 })}
        </p>
        <div className="mt-3 flex flex-wrap items-center gap-x-6 gap-y-2 text-sm">
          <span className={`flex items-center gap-1 ${overallReturn >= 0 ? 'text-forest-dark' : 'text-brick'}`}>
            {overallReturn >= 0 ? <TrendingUp size={16} /> : <TrendingDown size={16} />}
            {formatPct(overallReturn, { signed: true })} since first contribution
          </span>
          <span className="text-ink-soft">
            {formatZAR(totalContributed, { decimals: 0 })} contributed in total
          </span>
        </div>
      </section>

      {/* Key stats row */}
      <section className="grid grid-cols-2 gap-8 border-y border-line py-8 sm:grid-cols-4">
        <StatLine label="Cash on hand" value={formatZAR(portfolio.cashBalance, { decimals: 0 })} size="sm" />
        <StatLine label="Invested value" value={formatZAR(portfolio.holdingsValue, { decimals: 0 })} size="sm" />
        <StatLine
          label="Unrealized P&L"
          value={formatZAR(totalPnl, { decimals: 0 })}
          tone={totalPnl >= 0 ? 'positive' : 'negative'}
          size="sm"
        />
        <StatLine label="Holdings" value={portfolio.holdings.length} size="sm" />
      </section>

      {/* Allocation rule (audit-log contract summary) */}
      <LedgerSection title="How every contribution is split">
        <p className="mb-4 max-w-xl text-sm text-ink-soft">
          Every rand a member puts in follows the same fixed rule, logged on-chain for anyone to verify —
          no organizer can quietly change it.
        </p>
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-3">
          <AllocationBlock
            label="Invested in the market"
            pct={ALLOCATION_RULE.invest}
            amount={split.invest}
            tone="forest"
          />
          <AllocationBlock
            label="MTN infrastructure fee"
            pct={ALLOCATION_RULE.mtnFee}
            amount={split.mtnFee}
            tone="ochre"
          />
          <AllocationBlock
            label="Quarterly member payout"
            pct={ALLOCATION_RULE.quarterlyPayout}
            amount={split.quarterlyPayout}
            tone="brick"
          />
        </div>
      </LedgerSection>

      {/* Recent contributions */}
      <LedgerSection title="Recent contributions">
        {recentContributions.length === 0 ? (
          <EmptyState text="No contributions yet. Once members pay in, they'll show up here." />
        ) : (
          <LedgerTable columns={['Member', 'Amount', 'Date']}>
            {recentContributions.map((c) => (
              <LedgerRow key={c.id}>
                <LedgerCell>{c.member_name || c.member_id}</LedgerCell>
                <LedgerCell className="num-tabular">{formatZAR(c.amount)}</LedgerCell>
                <LedgerCell className="text-ink-soft">{formatDate(c.ts)}</LedgerCell>
              </LedgerRow>
            ))}
          </LedgerTable>
        )}
      </LedgerSection>

      {/* Top holdings preview */}
      <LedgerSection title="What the pool owns">
        {portfolio.holdings.length === 0 ? (
          <EmptyState text="The pool hasn't bought anything yet. Head to Trade to place the first order." />
        ) : (
          <LedgerTable columns={['Symbol', 'Qty', 'Avg price', 'Current', 'P&L']}>
            {portfolio.holdings.map((h) => (
              <LedgerRow key={h.symbol}>
                <LedgerCell className="font-medium">{h.symbol}</LedgerCell>
                <LedgerCell className="num-tabular">{h.quantity}</LedgerCell>
                <LedgerCell className="num-tabular text-ink-soft">{formatZAR(h.avgPrice)}</LedgerCell>
                <LedgerCell className="num-tabular">{formatZAR(h.currentPrice)}</LedgerCell>
                <LedgerCell>
                  <Badge tone={h.unrealizedPnl >= 0 ? 'filled' : 'rejected'}>
                    {formatZAR(h.unrealizedPnl, { decimals: 0 })} ({formatPct(h.unrealizedPnlPct, { signed: true })})
                  </Badge>
                </LedgerCell>
              </LedgerRow>
            ))}
          </LedgerTable>
        )}
      </LedgerSection>
    </div>
  );
}

function AllocationBlock({ label, pct, amount, tone }) {
  const barColor = { forest: 'bg-forest', ochre: 'bg-ochre', brick: 'bg-brick' }[tone];
  return (
    <div>
      <div className="mb-2 h-1.5 w-full rounded-full bg-ink/5">
        <div className={`h-1.5 rounded-full ${barColor}`} style={{ width: `${pct * 100}%` }} />
      </div>
      <p className="text-sm text-ink-soft">{label}</p>
      <p className="font-display text-xl">{formatPct(pct * 100, { decimals: 0 })}</p>
      <p className="text-sm text-ink-soft num-tabular">{formatZAR(amount, { decimals: 0 })} to date</p>
    </div>
  );
}

function EmptyState({ text }) {
  return <p className="rounded border border-dashed border-line px-4 py-8 text-center text-sm text-ink-soft">{text}</p>;
}
