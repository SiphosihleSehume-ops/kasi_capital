import { useCallback, useEffect, useRef, useState } from 'react';
import { api } from '../lib/api';

const POOL_ID = 'default-pool';

export function useStokvelData() {
  const [portfolio, setPortfolio] = useState(null);
  const [instruments, setInstruments] = useState([]);
  const [orders, setOrders] = useState([]);
  const [contributions, setContributions] = useState([]);
  const [liveDataStatus, setLiveDataStatus] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const pollRef = useRef(null);

  const refresh = useCallback(async () => {
    try {
      const [portfolioRes, instrumentsRes, ordersRes, contributionsRes, statusRes] = await Promise.all([
        api.getPortfolio(POOL_ID),
        api.getInstruments(),
        api.getOrders(POOL_ID),
        api.getContributions(POOL_ID),
        api.getLiveDataStatus().catch(() => null),
      ]);
      setPortfolio(portfolioRes);
      setInstruments(instrumentsRes.instruments);
      setOrders(ordersRes.orders);
      setContributions(contributionsRes.contributions);
      setLiveDataStatus(statusRes);
      setError(null);
    } catch (err) {
      setError(err.message || 'Could not reach the server');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
    pollRef.current = setInterval(refresh, 6000);
    return () => clearInterval(pollRef.current);
  }, [refresh]);

  return { portfolio, instruments, orders, contributions, liveDataStatus, loading, error, refresh, poolId: POOL_ID };
}
